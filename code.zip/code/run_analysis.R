test <- read.csv("X_test.csv")
test
train <- read.csv("X_train.csv")
train
names(test)
names(train)
merge_data <- merge(train, test)
merge_data

